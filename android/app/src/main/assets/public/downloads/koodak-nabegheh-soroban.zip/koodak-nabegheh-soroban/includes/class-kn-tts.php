<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KN_TTS {

	const OPTION_KEY        = 'kn_soroban_tts_settings';
	const CACHE_MAX_FILES   = 250;
	const HOURLY_IP_LIMIT   = 300;
	const MINUTE_IP_LIMIT   = 45;

	/**
	 * Catalog of supported AI TTS providers with safe HTTPS defaults.
	 */
	public static function get_providers_catalog() {
		return array(
			'gapgpt'     => array(
				'label'         => 'گپ‌جی‌پی‌تی ایرانی (GapGPT — سازگار با OpenAI)',
				'base_url'      => 'https://api.gapgpt.app/v1',
				'default_model' => 'gpt-4o-mini-tts',
				'default_voice' => 'nova',
				'models'        => array( 'gpt-4o-mini-tts', 'tts-1', 'tts-1-hd' ),
				'voices'        => array( 'nova', 'shimmer', 'coral', 'alloy', 'sage', 'ash', 'echo', 'fable', 'onyx' ),
				'hint'          => 'آدرس استاندارد: https://api.gapgpt.app/v1 (مسیر /audio/speech خودکار اضافه می‌شود).',
			),
			'openai'     => array(
				'label'         => 'OpenAI TTS رسمی',
				'base_url'      => 'https://api.openai.com/v1',
				'default_model' => 'gpt-4o-mini-tts',
				'default_voice' => 'nova',
				'models'        => array( 'gpt-4o-mini-tts', 'tts-1', 'tts-1-hd' ),
				'voices'        => array( 'nova', 'shimmer', 'coral', 'alloy', 'sage', 'ash', 'echo', 'fable', 'onyx' ),
				'hint'          => 'آدرس استاندارد: https://api.openai.com/v1',
			),
			'avalai'     => array(
				'label'         => 'آوا‌ای‌آی ایرانی (AvalAI — سازگار با OpenAI)',
				'base_url'      => 'https://api.avalai.ir/v1',
				'default_model' => 'gpt-4o-mini-tts',
				'default_voice' => 'nova',
				'models'        => array( 'gpt-4o-mini-tts', 'tts-1', 'tts-1-hd' ),
				'voices'        => array( 'nova', 'shimmer', 'coral', 'alloy', 'sage', 'ash', 'echo', 'fable', 'onyx' ),
				'hint'          => 'آدرس استاندارد: https://api.avalai.ir/v1',
			),
			'elevenlabs' => array(
				'label'         => 'ElevenLabs (صداگذاری طبیعی چندزبانه)',
				'base_url'      => 'https://api.elevenlabs.io/v1',
				'default_model' => 'eleven_multilingual_v2',
				'default_voice' => '21m00Tcm4TlvDq8ikWAM',
				'models'        => array( 'eleven_multilingual_v2', 'eleven_flash_v2_5', 'eleven_turbo_v2_5' ),
				'voices'        => array( '21m00Tcm4TlvDq8ikWAM', 'EXAVITQu4vr4xnSDxMaL', 'XB0fDUnXU5powFXDhCwa' ),
				'hint'          => 'در فیلد صدا (Voice) شناسه Voice ID الون‌لبز را وارد کنید (مثلاً 21m00Tcm4TlvDq8ikWAM).',
			),
			'gemini'     => array(
				'label'         => 'Google Gemini TTS',
				'base_url'      => 'https://generativelanguage.googleapis.com/v1beta',
				'default_model' => 'gemini-2.5-flash-preview-tts',
				'default_voice' => 'Kore',
				'models'        => array( 'gemini-2.5-flash-preview-tts', 'gemini-2.5-pro-preview-tts' ),
				'voices'        => array( 'Kore', 'Aoede', 'Zephyr', 'Puck', 'Charon', 'Fenrir' ),
				'hint'          => 'آدرس استاندارد: https://generativelanguage.googleapis.com/v1beta',
			),
			'custom'     => array(
				'label'         => 'سرویس دلخواه سازگار با OpenAI (/audio/speech)',
				'base_url'      => '',
				'default_model' => 'tts-1',
				'default_voice' => 'nova',
				'models'        => array( 'gpt-4o-mini-tts', 'tts-1', 'tts-1-hd' ),
				'voices'        => array( 'nova', 'shimmer', 'alloy', 'echo', 'fable', 'onyx' ),
				'hint'          => 'آدرس پایه API سرویس را با https وارد کنید (مثلاً https://example.com/v1).',
			),
		);
	}

	/**
	 * Default persisted configuration (no secrets).
	 */
	public static function get_defaults() {
		return array(
			'enabled'       => 0,
			'provider'      => 'gapgpt',
			'base_url'      => 'https://api.gapgpt.app/v1',
			'api_key'       => '',
			'model'         => 'gpt-4o-mini-tts',
			'voice'         => 'nova',
			'format'        => 'mp3',
			'speed'         => '0.95',
			'instructions'  => 'با لحن گرم، مهربان، شاد و شمرده به زبان فارسی معیار و کودکانه برای کودکان ۴ تا ۱۵ سال صحبت کن.',
			'cache_enabled' => 1,
			'require_auth'  => 0,
		);
	}

	/**
	 * Return full normalized settings (only for server-side / admin use; never expose api_key to public REST).
	 */
	public static function get_settings() {
		$defaults = self::get_defaults();
		$raw      = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}
		$merged = array_merge( $defaults, $raw );

		$catalog  = self::get_providers_catalog();
		$provider = sanitize_key( (string) $merged['provider'] );
		if ( ! isset( $catalog[ $provider ] ) ) {
			$provider = 'gapgpt';
		}

		$base_url = trim( (string) $merged['base_url'] );
		if ( $base_url === '' && ! empty( $catalog[ $provider ]['base_url'] ) ) {
			$base_url = $catalog[ $provider ]['base_url'];
		}

		$model = trim( sanitize_text_field( (string) $merged['model'] ) );
		if ( $model === '' ) {
			$model = $catalog[ $provider ]['default_model'];
		}

		$voice = trim( sanitize_text_field( (string) $merged['voice'] ) );
		if ( $voice === '' ) {
			$voice = $catalog[ $provider ]['default_voice'];
		}

		$format = strtolower( trim( sanitize_key( (string) $merged['format'] ) ) );
		if ( ! in_array( $format, array( 'mp3', 'wav', 'opus', 'aac' ), true ) ) {
			$format = 'mp3';
		}

		$speed_f = (float) $merged['speed'];
		if ( $speed_f < 0.5 || $speed_f > 2.0 ) {
			$speed_f = 0.95;
		}

		return array(
			'enabled'       => ! empty( $merged['enabled'] ) ? 1 : 0,
			'provider'      => $provider,
			'base_url'      => untrailingslashit( $base_url ),
			'api_key'       => trim( (string) $merged['api_key'] ),
			'model'         => $model,
			'voice'         => $voice,
			'format'        => $format,
			'speed'         => number_format( $speed_f, 2, '.', '' ),
			'instructions'  => sanitize_textarea_field( (string) $merged['instructions'] ),
			'cache_enabled' => ! empty( $merged['cache_enabled'] ) ? 1 : 0,
			'require_auth'  => ! empty( $merged['require_auth'] ) ? 1 : 0,
		);
	}

	/**
	 * Public safe provider name (without secrets).
	 */
	public static function get_public_provider() {
		$cfg = self::get_settings();
		return $cfg['provider'];
	}

	/**
	 * Whether server-side AI TTS is configured and active.
	 */
	public static function is_enabled() {
		$cfg = self::get_settings();
		if ( empty( $cfg['enabled'] ) || empty( $cfg['api_key'] ) ) {
			return false;
		}
		return self::validate_safe_external_base_url( $cfg['base_url'] ) !== '';
	}

	/**
	 * Strict SSRF-safe external HTTPS URL validation for AI provider base URLs.
	 */
	public static function validate_safe_external_base_url( $raw_url ) {
		$trimmed = untrailingslashit( trim( (string) $raw_url ) );
		if ( $trimmed === '' ) {
			return '';
		}
		$parsed = wp_parse_url( $trimmed );
		if ( ! is_array( $parsed ) || empty( $parsed['scheme'] ) || empty( $parsed['host'] ) ) {
			return '';
		}
		$scheme = strtolower( (string) $parsed['scheme'] );
		if ( $scheme !== 'https' ) {
			return '';
		}
		if ( ! empty( $parsed['user'] ) || ! empty( $parsed['pass'] ) ) {
			return '';
		}

		$host = strtolower( trim( (string) $parsed['host'], '[]' ) );
		if ( $host === '' || $host === 'localhost' || substr( $host, -6 ) === '.local' || substr( $host, -9 ) === '.internal' ) {
			return '';
		}

		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			if ( ! filter_var( $host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
				return '';
			}
		} else {
			$resolved = @gethostbynamel( $host );
			if ( is_array( $resolved ) && ! empty( $resolved ) ) {
				foreach ( $resolved as $ip ) {
					if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
						return '';
					}
				}
			}
		}

		return esc_url_raw( $trimmed );
	}

	/**
	 * Resolve upload cache directory for TTS audio files.
	 */
	private static function get_cache_dir() {
		$uploads = wp_upload_dir();
		if ( ! empty( $uploads['error'] ) || empty( $uploads['basedir'] ) ) {
			return '';
		}
		$dir = trailingslashit( $uploads['basedir'] ) . 'kn-tts-cache';
		if ( ! file_exists( $dir ) ) {
			if ( ! wp_mkdir_p( $dir ) ) {
				return '';
			}
			@file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" );
			@file_put_contents( $dir . '/.htaccess', "Deny from all\n" );
		}
		return is_writable( $dir ) ? $dir : '';
	}

	/**
	 * Clear all cached TTS audio files and return removed count.
	 */
	public static function clear_cache() {
		$uploads = wp_upload_dir();
		if ( empty( $uploads['basedir'] ) ) {
			return 0;
		}
		$dir = trailingslashit( $uploads['basedir'] ) . 'kn-tts-cache';
		if ( ! is_dir( $dir ) ) {
			return 0;
		}
		$files = glob( $dir . '/*.json' );
		$count = 0;
		if ( is_array( $files ) ) {
			foreach ( $files as $file ) {
				if ( is_file( $file ) && @unlink( $file ) ) {
					$count++;
				}
			}
		}
		return $count;
	}

	/**
	 * Count cached TTS phrases.
	 */
	public static function get_cache_count() {
		$uploads = wp_upload_dir();
		if ( empty( $uploads['basedir'] ) ) {
			return 0;
		}
		$dir = trailingslashit( $uploads['basedir'] ) . 'kn-tts-cache';
		if ( ! is_dir( $dir ) ) {
			return 0;
		}
		$files = glob( $dir . '/*.json' );
		return is_array( $files ) ? count( $files ) : 0;
	}

	private static function get_client_ip_hash() {
		$ip = '';
		if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) );
		} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$parts = explode( ',', sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) );
			$ip    = trim( (string) ( $parts[0] ?? '' ) );
		} elseif ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
		}
		return hash( 'sha256', $ip . '|' . wp_salt( 'nonce' ) );
	}

	private static function check_rate_limit() {
		$ip_hash = substr( self::get_client_ip_hash(), 0, 24 );
		$min_key = 'kn_tts_m_' . $ip_hash;
		$hr_key  = 'kn_tts_h_' . $ip_hash;

		$min_count = (int) get_transient( $min_key );
		if ( $min_count >= self::MINUTE_IP_LIMIT ) {
			return new WP_Error(
				'tts_rate_limited',
				'تعداد درخواست‌های تولید صدا بیش از حد مجاز است. لطفاً کمی صبر کنید.',
				array( 'status' => 429 )
			);
		}

		$hr_count = (int) get_transient( $hr_key );
		if ( $hr_count >= self::HOURLY_IP_LIMIT ) {
			return new WP_Error(
				'tts_rate_limited',
				'سقف ساعتی تولید صدای هوشمند پر شده است.',
				array( 'status' => 429 )
			);
		}

		set_transient( $min_key, $min_count + 1, MINUTE_IN_SECONDS );
		set_transient( $hr_key, $hr_count + 1, HOUR_IN_SECONDS );
		return true;
	}

	private static function format_to_mime( $format ) {
		switch ( strtolower( (string) $format ) ) {
			case 'wav':
				return 'audio/wav';
			case 'opus':
				return 'audio/ogg';
			case 'aac':
				return 'audio/aac';
			case 'mp3':
			default:
				return 'audio/mpeg';
		}
	}

	private static function tone_instruction( $tone, $base_instructions ) {
		$tone_hint = '';
		if ( $tone === 'cheer' ) {
			$tone_hint = 'لحن بسیار شاد، پرانرژی و تشویق‌کننده برای تحسین موفقیت کودک داشته باش.';
		} elseif ( $tone === 'encourage' ) {
			$tone_hint = 'لحن بسیار مهربان، آرامش‌بخش و دلگرم‌کننده برای تشویق کودک به تلاش دوباره داشته باش.';
		} else {
			$tone_hint = 'لحن آموزگار مهربان، واضح و صمیمی برای آموزش کودک داشته باش.';
		}
		$clean_base = trim( (string) $base_instructions );
		return $clean_base !== '' ? ( $clean_base . ' ' . $tone_hint ) : $tone_hint;
	}

	/**
	 * Wrap raw 16-bit PCM bytes (e.g. from Gemini TTS) in a standard RIFF/WAV header.
	 */
	private static function wrap_pcm_as_wav( $pcm_bytes, $sample_rate = 24000, $channels = 1, $bits_per_sample = 16 ) {
		$data_size   = strlen( $pcm_bytes );
		$byte_rate   = (int) ( $sample_rate * $channels * ( $bits_per_sample / 8 ) );
		$block_align = (int) ( $channels * ( $bits_per_sample / 8 ) );

		$header = pack(
			'A4VA4A4VvvVVvvA4V',
			'RIFF',
			36 + $data_size,
			'WAVE',
			'fmt ',
			16,
			1,
			$channels,
			$sample_rate,
			$byte_rate,
			$block_align,
			$bits_per_sample,
			'data',
			$data_size
		);

		return $header . $pcm_bytes;
	}

	/**
	 * Handle public/app REST synthesis request.
	 */
	public static function handle_rest_tts( WP_REST_Request $request ) {
		$cfg = self::get_settings();
		if ( empty( $cfg['enabled'] ) ) {
			return new WP_Error(
				'tts_disabled',
				'سرویس تولید صدای هوشمند در وردپرس غیرفعال است.',
				array( 'status' => 503 )
			);
		}

		if ( ! empty( $cfg['require_auth'] ) ) {
			$user = KN_Auth::authenticate_request( $request );
			if ( ! $user ) {
				return new WP_Error(
					'kn_unauthorized',
					'برای استفاده از گوینده هوشمند ابتدا وارد حساب کاربری خود شوید.',
					array( 'status' => 401 )
				);
			}
		}

		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $request->get_params();
		}

		$raw_text = isset( $params['text'] ) ? trim( sanitize_textarea_field( (string) $params['text'] ) ) : '';
		if ( $raw_text === '' ) {
			return new WP_Error( 'tts_text_required', 'متن برای تولید صدا الزامی است.', array( 'status' => 400 ) );
		}
		if ( mb_strlen( $raw_text, 'UTF-8' ) > 400 ) {
			return new WP_Error( 'tts_text_too_long', 'حداکثر طول متن ۴۰۰ کاراکتر است.', array( 'status' => 400 ) );
		}

		$raw_tone = isset( $params['tone'] ) ? sanitize_key( (string) $params['tone'] ) : 'teach';
		$tone     = in_array( $raw_tone, array( 'teach', 'cheer', 'encourage' ), true ) ? $raw_tone : 'teach';

		$result = self::synthesize( $raw_text, $tone, false );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response( $result );
	}

	/**
	 * Synthesize Persian speech using the configured AI provider with optional server-side caching.
	 */
	public static function synthesize( $text, $tone = 'teach', $bypass_cache = false ) {
		$cfg = self::get_settings();

		if ( empty( $cfg['api_key'] ) ) {
			return new WP_Error(
				'tts_missing_key',
				'کلید API سرویس تبدیل متن به صدا در وردپرس وارد نشده است.',
				array( 'status' => 503 )
			);
		}

		$safe_base = self::validate_safe_external_base_url( $cfg['base_url'] );
		if ( $safe_base === '' ) {
			return new WP_Error(
				'tts_invalid_base_url',
				'آدرس پایه API سرویس باید یک دامنه عمومی معتبر با https باشد.',
				array( 'status' => 400 )
			);
		}

		$cache_dir  = ( ! $bypass_cache && ! empty( $cfg['cache_enabled'] ) ) ? self::get_cache_dir() : '';
		$cache_hash = hash(
			'sha256',
			implode(
				'|',
				array(
					$cfg['provider'],
					$safe_base,
					$cfg['model'],
					$cfg['voice'],
					$cfg['format'],
					$cfg['speed'],
					$cfg['instructions'],
					$tone,
					$text,
				)
			)
		);
		$cache_file = $cache_dir !== '' ? ( $cache_dir . '/' . $cache_hash . '.json' ) : '';

		if ( $cache_file !== '' && file_exists( $cache_file ) ) {
			$cached_raw  = @file_get_contents( $cache_file );
			$cached_json = json_decode( (string) $cached_raw, true );
			if ( is_array( $cached_json ) && ! empty( $cached_json['audioBase64'] ) ) {
				@touch( $cache_file );
				return array(
					'audioBase64' => (string) $cached_json['audioBase64'],
					'mimeType'    => (string) ( $cached_json['mimeType'] ?? 'audio/mpeg' ),
					'provider'    => $cfg['provider'],
					'cached'      => true,
				);
			}
		}

		if ( ! $bypass_cache ) {
			$rate_ok = self::check_rate_limit();
			if ( is_wp_error( $rate_ok ) ) {
				return $rate_ok;
			}
		}

		$provider = $cfg['provider'];
		if ( $provider === 'elevenlabs' ) {
			$res = self::call_elevenlabs( $safe_base, $cfg, $text );
		} elseif ( $provider === 'gemini' ) {
			$res = self::call_gemini_tts( $safe_base, $cfg, $text, $tone );
		} else {
			// gapgpt, openai, avalai, custom -> OpenAI-compatible /audio/speech
			$res = self::call_openai_compatible( $safe_base, $cfg, $text, $tone );
		}

		if ( is_wp_error( $res ) ) {
			return $res;
		}

		if ( $cache_file !== '' && ! empty( $res['audioBase64'] ) ) {
			self::prune_cache_if_needed( $cache_dir );
			@file_put_contents(
				$cache_file,
				wp_json_encode(
					array(
						'audioBase64' => $res['audioBase64'],
						'mimeType'    => $res['mimeType'],
						'provider'    => $provider,
						'createdAt'   => time(),
					)
				)
			);
		}

		$res['provider'] = $provider;
		$res['cached']   = false;
		return $res;
	}

	private static function prune_cache_if_needed( $cache_dir ) {
		$files = glob( $cache_dir . '/*.json' );
		if ( ! is_array( $files ) || count( $files ) < self::CACHE_MAX_FILES ) {
			return;
		}
		usort(
			$files,
			function ( $a, $b ) {
				return (int) @filemtime( $a ) - (int) @filemtime( $b );
			}
		);
		$to_remove = count( $files ) - self::CACHE_MAX_FILES + 10;
		for ( $i = 0; $i < $to_remove && isset( $files[ $i ] ); $i++ ) {
			@unlink( $files[ $i ] );
		}
	}

	private static function extract_api_error_message( $raw_body ) {
		$decoded = json_decode( (string) $raw_body, true );
		if ( is_array( $decoded ) ) {
			if ( isset( $decoded['error']['message'] ) && is_string( $decoded['error']['message'] ) ) {
				return sanitize_text_field( $decoded['error']['message'] );
			}
			if ( isset( $decoded['detail']['message'] ) && is_string( $decoded['detail']['message'] ) ) {
				return sanitize_text_field( $decoded['detail']['message'] );
			}
			if ( isset( $decoded['message'] ) && is_string( $decoded['message'] ) ) {
				return sanitize_text_field( $decoded['message'] );
			}
		}
		return '';
	}

	/**
	 * Call GapGPT / OpenAI / AvalAI / Custom OpenAI-compatible POST {base_url}/audio/speech.
	 */
	private static function call_openai_compatible( $base_url, $cfg, $text, $tone ) {
		$endpoint = untrailingslashit( $base_url );
		if ( substr( $endpoint, -13 ) !== '/audio/speech' ) {
			$endpoint .= '/audio/speech';
		}

		$payload = array(
			'model'           => $cfg['model'],
			'input'           => $text,
			'voice'           => $cfg['voice'],
			'response_format' => $cfg['format'],
			'speed'           => (float) $cfg['speed'],
		);

		// Only send 'instructions' on models that support steerability (e.g. gpt-4o-mini-tts)
		$lower_model = strtolower( (string) $cfg['model'] );
		if ( strpos( $lower_model, '4o' ) !== false || strpos( $lower_model, 'instruct' ) !== false ) {
			$instr = self::tone_instruction( $tone, $cfg['instructions'] );
			if ( $instr !== '' ) {
				$payload['instructions'] = $instr;
			}
		}

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => 30,
				'headers' => array(
					'Authorization' => 'Bearer ' . $cfg['api_key'],
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'tts_network_error',
				'خطا در برقراری ارتباط با سرور هوش مصنوعی: ' . $response->get_error_message(),
				array( 'status' => 502 )
			);
		}

		$http_code = (int) wp_remote_retrieve_response_code( $response );
		$raw_body  = (string) wp_remote_retrieve_body( $response );
		$resp_ct   = strtolower( (string) wp_remote_retrieve_header( $response, 'content-type' ) );

		if ( $http_code < 200 || $http_code >= 300 || strpos( $resp_ct, 'application/json' ) !== false ) {
			$msg = self::extract_api_error_message( $raw_body );
			return new WP_Error(
				'tts_provider_error',
				$msg !== ''
					? sprintf( 'خطای سرویس هوش مصنوعی (%d): %s', $http_code, $msg )
					: sprintf( 'پاسخ نامعتبر از سرویس هوش مصنوعی (کد %d).', $http_code ),
				array( 'status' => 502 )
			);
		}

		if ( strlen( $raw_body ) < 128 ) {
			return new WP_Error( 'tts_empty_audio', 'فایل صوتی معتبری از سرویس دریافت نشد.', array( 'status' => 502 ) );
		}

		$mime = self::format_to_mime( $cfg['format'] );
		if ( strpos( $resp_ct, 'audio/' ) !== false ) {
			$parts = explode( ';', $resp_ct );
			$mime  = trim( $parts[0] );
		}

		return array(
			'audioBase64' => base64_encode( $raw_body ),
			'mimeType'    => $mime,
		);
	}

	/**
	 * Call ElevenLabs TTS API.
	 */
	private static function call_elevenlabs( $base_url, $cfg, $text ) {
		$voice_id = rawurlencode( $cfg['voice'] );
		$endpoint = untrailingslashit( $base_url ) . '/text-to-speech/' . $voice_id;

		$payload = array(
			'text'           => $text,
			'model_id'       => $cfg['model'],
			'voice_settings' => array(
				'stability'        => 0.55,
				'similarity_boost' => 0.78,
			),
		);

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => 30,
				'headers' => array(
					'xi-api-key'   => $cfg['api_key'],
					'Content-Type' => 'application/json',
					'Accept'       => 'audio/mpeg',
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'tts_network_error',
				'خطا در اتصال به ElevenLabs: ' . $response->get_error_message(),
				array( 'status' => 502 )
			);
		}

		$http_code = (int) wp_remote_retrieve_response_code( $response );
		$raw_body  = (string) wp_remote_retrieve_body( $response );
		$resp_ct   = strtolower( (string) wp_remote_retrieve_header( $response, 'content-type' ) );

		if ( $http_code < 200 || $http_code >= 300 || strpos( $resp_ct, 'application/json' ) !== false ) {
			$msg = self::extract_api_error_message( $raw_body );
			return new WP_Error(
				'tts_provider_error',
				$msg !== ''
					? sprintf( 'خطای ElevenLabs (%d): %s', $http_code, $msg )
					: sprintf( 'پاسخ نامعتبر از ElevenLabs (کد %d).', $http_code ),
				array( 'status' => 502 )
			);
		}

		return array(
			'audioBase64' => base64_encode( $raw_body ),
			'mimeType'    => 'audio/mpeg',
		);
	}

	/**
	 * Call Google Gemini TTS REST API.
	 */
	private static function call_gemini_tts( $base_url, $cfg, $text, $tone ) {
		$model    = rawurlencode( $cfg['model'] );
		$endpoint = untrailingslashit( $base_url ) . '/models/' . $model . ':generateContent';

		$instr = self::tone_instruction( $tone, $cfg['instructions'] );
		$prompt_text = $instr !== '' ? ( $instr . "\n\nمتن برای خواندن:\n" . $text ) : $text;

		$payload = array(
			'contents'         => array(
				array(
					'role'  => 'user',
					'parts' => array(
						array( 'text' => $prompt_text ),
					),
				),
			),
			'generationConfig' => array(
				'responseModalities' => array( 'AUDIO' ),
				'speechConfig'       => array(
					'voiceConfig' => array(
						'prebuiltVoiceConfig' => array(
							'voiceName' => $cfg['voice'],
						),
					),
				),
			),
		);

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => 30,
				'headers' => array(
					'x-goog-api-key' => $cfg['api_key'],
					'Content-Type'   => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'tts_network_error',
				'خطا در اتصال به Gemini TTS: ' . $response->get_error_message(),
				array( 'status' => 502 )
			);
		}

		$http_code = (int) wp_remote_retrieve_response_code( $response );
		$raw_body  = (string) wp_remote_retrieve_body( $response );
		$decoded   = json_decode( $raw_body, true );

		if ( $http_code < 200 || $http_code >= 300 || ! is_array( $decoded ) ) {
			$msg = self::extract_api_error_message( $raw_body );
			return new WP_Error(
				'tts_provider_error',
				$msg !== ''
					? sprintf( 'خطای Gemini TTS (%d): %s', $http_code, $msg )
					: sprintf( 'پاسخ نامعتبر از Gemini TTS (کد %d).', $http_code ),
				array( 'status' => 502 )
			);
		}

		$inline = $decoded['candidates'][0]['content']['parts'][0]['inlineData'] ?? null;
		if ( ! is_array( $inline ) || empty( $inline['data'] ) ) {
			return new WP_Error( 'tts_empty_audio', 'داده صوتی در پاسخ Gemini یافت نشد.', array( 'status' => 502 ) );
		}

		$b64       = (string) $inline['data'];
		$raw_mime  = strtolower( (string) ( $inline['mimeType'] ?? 'audio/wav' ) );

		// Gemini often returns raw linear16 PCM (audio/L16;codec=pcm;rate=24000); wrap in WAV header for browser <audio>.
		if ( strpos( $raw_mime, 'l16' ) !== false || strpos( $raw_mime, 'pcm' ) !== false ) {
			$rate = 24000;
			if ( preg_match( '/rate=(\d+)/', $raw_mime, $m ) ) {
				$rate = max( 8000, min( 48000, (int) $m[1] ) );
			}
			$pcm = base64_decode( $b64, true );
			if ( $pcm !== false ) {
				$wav = self::wrap_pcm_as_wav( $pcm, $rate, 1, 16 );
				return array(
					'audioBase64' => base64_encode( $wav ),
					'mimeType'    => 'audio/wav',
				);
			}
		}

		$mime_parts = explode( ';', $raw_mime );
		return array(
			'audioBase64' => $b64,
			'mimeType'    => trim( $mime_parts[0] ) ?: 'audio/wav',
		);
	}
}
